package com.codemc.custommobpowers.commands;

import com.codemc.custommobpowers.heads.HeadFactory;
import com.codemc.custommobpowers.menu.HeadMenu;
import org.bukkit.ChatColor;
import org.bukkit.command.Command;
import org.bukkit.command.CommandExecutor;
import org.bukkit.command.CommandSender;
import org.bukkit.configuration.ConfigurationSection;
import org.bukkit.entity.Player;
import org.bukkit.inventory.ItemStack;
import org.bukkit.plugin.Plugin;

import java.util.Locale;

/**
 * /getmobhead <mob> - gives the sender a custom mob head directly.
 * /getmobhead menu   - opens the full GUI instead.
 * Op only (enforced by plugin.yml permission default).
 */
public class GetMobHeadCommand implements CommandExecutor {

    private final Plugin plugin;

    public GetMobHeadCommand(Plugin plugin) {
        this.plugin = plugin;
    }

    @Override
    public boolean onCommand(CommandSender sender, Command command, String label, String[] args) {
        if (!(sender instanceof Player player)) {
            sender.sendMessage("Only players can use this command.");
            return true;
        }

        if (args.length == 0) {
            player.openInventory(HeadMenu.build(plugin));
            return true;
        }

        String mobName = args[0].toUpperCase(Locale.ROOT);
        ConfigurationSection textures = plugin.getConfig().getConfigurationSection("textures");
        String texture = textures != null ? textures.getString(mobName) : null;

        ItemStack head = HeadFactory.createHead(mobName, capitalize(args[0]), texture);
        player.getInventory().addItem(head);
        player.sendMessage(ChatColor.GREEN + "Gave you a " + capitalize(args[0]) + " head.");
        return true;
    }

    private String capitalize(String s) {
        if (s.isEmpty()) {
            return s;
        }
        return Character.toUpperCase(s.charAt(0)) + s.substring(1).toLowerCase(Locale.ROOT);
    }
}
