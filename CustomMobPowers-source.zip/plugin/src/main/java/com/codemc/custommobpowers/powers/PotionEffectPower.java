package com.codemc.custommobpowers.powers;

import org.bukkit.entity.Player;
import org.bukkit.potion.PotionEffect;
import org.bukkit.potion.PotionEffectType;

/**
 * Generic power for mobs that just grant a constant potion effect while
 * their head is worn. Used for every mob configured under
 * "default-powers" in config.yml rather than hand-coded in Java.
 */
public class PotionEffectPower implements Power {

    private static final int INFINITE_DURATION = Integer.MAX_VALUE;

    private final PotionEffectType effectType;
    private final int amplifier;

    public PotionEffectPower(PotionEffectType effectType, int amplifier) {
        this.effectType = effectType;
        this.amplifier = amplifier;
    }

    @Override
    public void onEquip(Player player) {
        apply(player);
    }

    @Override
    public void onUnequip(Player player) {
        player.removePotionEffect(effectType);
    }

    @Override
    public void tick(Player player) {
        PotionEffect current = player.getPotionEffect(effectType);
        if (current == null || current.getAmplifier() != amplifier) {
            apply(player);
        }
    }

    private void apply(Player player) {
        player.addPotionEffect(new PotionEffect(effectType, INFINITE_DURATION, amplifier, true, false, false));
    }
}
