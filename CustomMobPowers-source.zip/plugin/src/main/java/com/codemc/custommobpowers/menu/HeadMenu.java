package com.codemc.custommobpowers.menu;

import com.codemc.custommobpowers.heads.HeadFactory;
import org.bukkit.Bukkit;
import org.bukkit.configuration.ConfigurationSection;
import org.bukkit.inventory.Inventory;
import org.bukkit.inventory.ItemStack;
import org.bukkit.plugin.Plugin;

import java.util.ArrayList;
import java.util.List;
import java.util.Locale;

/**
 * Builds the admin-only GUI listing every mob head the plugin knows about
 * (every entry in config.yml's "default-powers" section, plus the four
 * hand-built ones: Slime, Cave Spider, Spider, Vex).
 */
public final class HeadMenu {

    private HeadMenu() {
    }

    public static Inventory build(Plugin plugin) {
        List<String> mobNames = collectMobNames(plugin);

        int rows = Math.max(1, (int) Math.ceil(mobNames.size() / 9.0));
        rows = Math.min(rows, 6);

        HeadMenuHolder holder = new HeadMenuHolder();
        Inventory inventory = Bukkit.createInventory(holder, rows * 9, "Mob Head Menu");
        holder.setInventory(inventory);

        ConfigurationSection textures = plugin.getConfig().getConfigurationSection("textures");

        for (String mobName : mobNames) {
            String texture = textures != null ? textures.getString(mobName) : null;
            String displayName = toDisplayName(mobName);
            ItemStack head = HeadFactory.createHead(mobName, displayName, texture);
            inventory.addItem(head);
        }

        return inventory;
    }

    private static List<String> collectMobNames(Plugin plugin) {
        List<String> names = new ArrayList<>(List.of("SLIME", "CAVE_SPIDER", "SPIDER", "VEX"));

        ConfigurationSection section = plugin.getConfig().getConfigurationSection("default-powers");
        if (section != null) {
            names.addAll(section.getKeys(false));
        }

        return names;
    }

    private static String toDisplayName(String mobName) {
        String[] parts = mobName.toLowerCase(Locale.ROOT).split("_");
        StringBuilder builder = new StringBuilder();
        for (String part : parts) {
            if (!part.isEmpty()) {
                builder.append(Character.toUpperCase(part.charAt(0))).append(part.substring(1)).append(' ');
            }
        }
        return builder.toString().trim();
    }
}
