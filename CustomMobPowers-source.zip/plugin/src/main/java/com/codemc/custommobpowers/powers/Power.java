package com.codemc.custommobpowers.powers;

import org.bukkit.entity.Player;

/**
 * Represents a power granted to a player while they wear a specific
 * custom mob head in their helmet slot.
 */
public interface Power {

    /**
     * Called once, the moment the head is equipped into the helmet slot.
     */
    void onEquip(Player player);

    /**
     * Called once, the moment the head leaves the helmet slot
     * (removed, swapped, player died and dropped it, etc).
     */
    void onUnequip(Player player);

    /**
     * Called every server tick (20/sec) while the head is equipped.
     * Default no-op; override for powers that need continuous upkeep
     * (e.g. re-applying an infinite potion effect).
     */
    default void tick(Player player) {
    }
}
