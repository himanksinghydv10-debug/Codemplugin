package com.codemc.custommobpowers;

import com.codemc.custommobpowers.commands.GetMobHeadCommand;
import com.codemc.custommobpowers.commands.RemoveMobHeadCommand;
import com.codemc.custommobpowers.heads.HeadKeys;
import com.codemc.custommobpowers.listeners.ArmorEquipListener;
import com.codemc.custommobpowers.listeners.HeadMenuListener;
import com.codemc.custommobpowers.listeners.MenuTriggerListener;
import com.codemc.custommobpowers.listeners.MobDeathListener;
import com.codemc.custommobpowers.powers.PowerRegistry;
import com.codemc.custommobpowers.tasks.PowerTickTask;
import org.bukkit.plugin.java.JavaPlugin;

public class CustomMobPowers extends JavaPlugin {

    private PowerRegistry powerRegistry;

    @Override
    public void onEnable() {
        saveDefaultConfig();

        HeadKeys.init(this);
        this.powerRegistry = new PowerRegistry(this);

        getServer().getPluginManager().registerEvents(new ArmorEquipListener(powerRegistry), this);
        getServer().getPluginManager().registerEvents(new MenuTriggerListener(this), this);
        getServer().getPluginManager().registerEvents(new HeadMenuListener(), this);
        getServer().getPluginManager().registerEvents(new MobDeathListener(this), this);

        getCommand("getmobhead").setExecutor(new GetMobHeadCommand(this));
        getCommand("removemobhead").setExecutor(new RemoveMobHeadCommand(powerRegistry));

        new PowerTickTask(powerRegistry).runTaskTimer(this, 20L, 20L);

        getLogger().info("CustomMobPowers enabled - " + powerRegistry.getClass().getSimpleName() + " loaded.");
    }

    @Override
    public void onDisable() {
        getLogger().info("CustomMobPowers disabled.");
    }

    public PowerRegistry getPowerRegistry() {
        return powerRegistry;
    }
}
