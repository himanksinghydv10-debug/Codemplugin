package com.codemc.custommobpowers.tasks;

import com.codemc.custommobpowers.heads.HeadFactory;
import com.codemc.custommobpowers.powers.Power;
import com.codemc.custommobpowers.powers.PowerRegistry;
import org.bukkit.Bukkit;
import org.bukkit.entity.Player;
import org.bukkit.inventory.ItemStack;
import org.bukkit.scheduler.BukkitRunnable;

/**
 * Runs every second and re-applies each worn head's power, so effects like
 * infinite Jump Boost survive things like death, milk buckets, or other
 * plugins clearing potion effects.
 */
public class PowerTickTask extends BukkitRunnable {

    private final PowerRegistry registry;

    public PowerTickTask(PowerRegistry registry) {
        this.registry = registry;
    }

    @Override
    public void run() {
        for (Player player : Bukkit.getOnlinePlayers()) {
            ItemStack helmet = player.getInventory().getHelmet();
            String mobType = HeadFactory.getMobType(helmet);
            if (mobType == null) {
                continue;
            }
            Power power = registry.getPower(mobType);
            if (power != null) {
                power.tick(player);
            }
        }
    }
}
