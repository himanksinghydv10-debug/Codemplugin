package com.codemc.custommobpowers.powers;

import org.bukkit.Bukkit;
import org.bukkit.entity.Player;
import org.bukkit.profile.PlayerProfile;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Random;
import java.util.UUID;

/**
 * Cave Spider head: disguises the wearer as a random online player
 * (name + skin). The target is picked once when equipped and stays
 * until the head is removed.
 */
public class CaveSpiderPower implements Power {

    private final Random random = new Random();
    // Stores the wearer's original profile so it can be restored on unequip.
    private final Map<UUID, PlayerProfile> originalProfiles = new HashMap<>();
    private final boolean allowSelf;

    public CaveSpiderPower(boolean allowSelf) {
        this.allowSelf = allowSelf;
    }

    @Override
    public void onEquip(Player player) {
        if (originalProfiles.containsKey(player.getUniqueId())) {
            return; // already disguised
        }

        List<Player> candidates = new ArrayList<>(Bukkit.getOnlinePlayers());
        if (!allowSelf) {
            candidates.remove(player);
        }
        if (candidates.isEmpty()) {
            return; // nobody to copy, no-op
        }

        Player target = candidates.get(random.nextInt(candidates.size()));

        originalProfiles.put(player.getUniqueId(), player.getPlayerProfile());

        PlayerProfile disguiseProfile = Bukkit.createProfile(player.getUniqueId(), target.getName());
        // Copy the target's skin/texture properties onto the disguise profile.
        disguiseProfile.getProperties().addAll(target.getPlayerProfile().getProperties());

        player.setPlayerProfile(disguiseProfile);
        refreshAppearance(player);
    }

    @Override
    public void onUnequip(Player player) {
        PlayerProfile original = originalProfiles.remove(player.getUniqueId());
        if (original != null) {
            player.setPlayerProfile(original);
            refreshAppearance(player);
        }
    }

    /**
     * Forces nearby players to re-render this player's entity so the new
     * skin/name actually shows up, by briefly hiding and re-showing them.
     */
    private void refreshAppearance(Player player) {
        for (Player viewer : Bukkit.getOnlinePlayers()) {
            if (viewer.equals(player)) {
                continue;
            }
            viewer.hidePlayer(Bukkit.getPluginManager().getPlugin("CustomMobPowers"), player);
            viewer.showPlayer(Bukkit.getPluginManager().getPlugin("CustomMobPowers"), player);
        }
    }
}
