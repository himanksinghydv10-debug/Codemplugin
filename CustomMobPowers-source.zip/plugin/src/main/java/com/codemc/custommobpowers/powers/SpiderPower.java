package com.codemc.custommobpowers.powers;

import org.bukkit.Bukkit;
import org.bukkit.entity.Player;
import org.bukkit.scoreboard.NameTagVisibility;
import org.bukkit.scoreboard.Scoreboard;
import org.bukkit.scoreboard.Team;

/**
 * Spider head: makes the wearer's nametag invisible to everyone,
 * using a dedicated scoreboard team with NameTagVisibility.NEVER.
 */
public class SpiderPower implements Power {

    private static final String TEAM_NAME = "cmp_no_nametag";

    @Override
    public void onEquip(Player player) {
        Team team = getOrCreateTeam();
        team.addEntry(player.getName());
    }

    @Override
    public void onUnequip(Player player) {
        Team team = getOrCreateTeam();
        team.removeEntry(player.getName());
    }

    private Team getOrCreateTeam() {
        Scoreboard scoreboard = Bukkit.getScoreboardManager().getMainScoreboard();
        Team team = scoreboard.getTeam(TEAM_NAME);
        if (team == null) {
            team = scoreboard.registerNewTeam(TEAM_NAME);
            team.setNameTagVisibility(NameTagVisibility.NEVER);
        }
        return team;
    }
}
