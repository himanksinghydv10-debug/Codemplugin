package com.codemc.custommobpowers.heads;

import org.bukkit.NamespacedKey;
import org.bukkit.plugin.Plugin;

/**
 * Central place for the plugin's PersistentDataContainer keys.
 */
public final class HeadKeys {

    private static NamespacedKey mobTypeKey;

    private HeadKeys() {
    }

    public static void init(Plugin plugin) {
        mobTypeKey = new NamespacedKey(plugin, "mob_power_type");
    }

    /**
     * Key used to tag a skull ItemStack with the EntityType name (e.g. "SLIME")
     * it grants a power for.
     */
    public static NamespacedKey mobType() {
        return mobTypeKey;
    }
}
