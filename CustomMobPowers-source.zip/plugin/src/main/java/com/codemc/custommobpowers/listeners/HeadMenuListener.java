package com.codemc.custommobpowers.listeners;

import com.codemc.custommobpowers.menu.HeadMenuHolder;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.inventory.InventoryClickEvent;
import org.bukkit.event.Listener;
import org.bukkit.inventory.ItemStack;

/**
 * Handles clicks inside the Mob Head Menu: gives the clicked head to the
 * player instead of letting them take it out of the menu's own inventory
 * (so the menu stays fully stocked for the next admin who opens it).
 */
public class HeadMenuListener implements Listener {

    @EventHandler
    public void onMenuClick(InventoryClickEvent event) {
        if (!(event.getInventory().getHolder() instanceof HeadMenuHolder)) {
            return;
        }

        event.setCancelled(true);

        ItemStack clicked = event.getCurrentItem();
        if (clicked == null || clicked.getType().isAir()) {
            return;
        }

        if (!(event.getWhoClicked() instanceof Player player)) {
            return;
        }

        player.getInventory().addItem(clicked.clone());
    }
}
