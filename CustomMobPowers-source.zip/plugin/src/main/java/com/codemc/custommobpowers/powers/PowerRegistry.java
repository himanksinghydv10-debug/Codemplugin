package com.codemc.custommobpowers.powers;

import org.bukkit.configuration.ConfigurationSection;
import org.bukkit.potion.PotionEffectType;
import org.bukkit.plugin.Plugin;

import java.util.HashMap;
import java.util.Locale;
import java.util.Map;
import java.util.logging.Level;

/**
 * Maps mob-type names (e.g. "SLIME", "ZOMBIE") to the Power that should be
 * granted while a matching head is worn. Hand-built unique powers take
 * priority; every other mob listed in config.yml's "default-powers"
 * section gets a simple PotionEffectPower.
 */
public class PowerRegistry {

    private final Map<String, Power> powers = new HashMap<>();

    public PowerRegistry(Plugin plugin) {
        registerUniquePowers(plugin);
        registerConfiguredPowers(plugin);
    }

    private void registerUniquePowers(Plugin plugin) {
        boolean allowSelfDisguise = plugin.getConfig().getBoolean("cave-spider-disguise.allow-self", true);
        boolean restoreGamemode = plugin.getConfig().getBoolean("vex-power.restore-previous-gamemode", true);

        powers.put("SLIME", new SlimePower());
        powers.put("CAVE_SPIDER", new CaveSpiderPower(allowSelfDisguise));
        powers.put("SPIDER", new SpiderPower());
        powers.put("VEX", new VexPower(restoreGamemode));
    }

    private void registerConfiguredPowers(Plugin plugin) {
        ConfigurationSection section = plugin.getConfig().getConfigurationSection("default-powers");
        if (section == null) {
            return;
        }

        for (String mobName : section.getKeys(false)) {
            String key = mobName.toUpperCase(Locale.ROOT);
            if (powers.containsKey(key)) {
                continue; // don't override a hand-built power
            }

            String value = section.getString(mobName);
            if (value == null || !value.contains(":")) {
                plugin.getLogger().log(Level.WARNING,
                        "Skipping invalid default-powers entry for " + mobName + " (expected EFFECT:AMPLIFIER)");
                continue;
            }

            String[] parts = value.split(":", 2);
            PotionEffectType effectType = PotionEffectType.getByName(parts[0].toUpperCase(Locale.ROOT));
            if (effectType == null) {
                plugin.getLogger().log(Level.WARNING,
                        "Unknown potion effect '" + parts[0] + "' for mob " + mobName);
                continue;
            }

            int amplifier;
            try {
                amplifier = Integer.parseInt(parts[1].trim());
            } catch (NumberFormatException e) {
                amplifier = 0;
            }

            powers.put(key, new PotionEffectPower(effectType, amplifier));
        }
    }

    public Power getPower(String mobName) {
        if (mobName == null) {
            return null;
        }
        return powers.get(mobName.toUpperCase(Locale.ROOT));
    }

    public boolean hasPower(String mobName) {
        return getPower(mobName) != null;
    }
}
