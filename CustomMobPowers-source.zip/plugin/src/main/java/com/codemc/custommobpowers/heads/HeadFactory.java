package com.codemc.custommobpowers.heads;

import org.bukkit.Bukkit;
import org.bukkit.ChatColor;
import org.bukkit.Material;
import org.bukkit.NamespacedKey;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.meta.SkullMeta;
import org.bukkit.profile.PlayerProfile;
import org.bukkit.profile.PlayerTextures;

import java.net.MalformedURLException;
import java.net.URL;
import java.util.Locale;
import java.util.Map;
import java.util.UUID;

/**
 * Builds the custom mob head ItemStacks. Vanilla mobs that already have a
 * dedicated head/skull item (Zombie, Skeleton, Wither Skeleton, Creeper,
 * Piglin, Dragon) use that vanilla item directly. Every other mob uses a
 * player head (PLAYER_HEAD) with a custom skin texture pulled from
 * config.yml's "textures" section (a base64 Mojang texture value, or a
 * direct skin URL). If no texture is configured, a plain player head is
 * used so the plugin still functions.
 */
public final class HeadFactory {

    private HeadFactory() {
    }

    private static final Map<String, Material> VANILLA_HEADS = Map.of(
            "ZOMBIE", Material.ZOMBIE_HEAD,
            "SKELETON", Material.SKELETON_SKULL,
            "WITHER_SKELETON", Material.WITHER_SKELETON_SKULL,
            "CREEPER", Material.CREEPER_HEAD,
            "PIGLIN", Material.PIGLIN_HEAD,
            "ENDER_DRAGON", Material.DRAGON_HEAD
    );

    /**
     * Creates a head ItemStack for the given mob (EntityType name, e.g. "SLIME").
     *
     * @param mobName     upper-case EntityType name
     * @param displayName human readable name shown on the item
     * @param textureUrl  a Mojang skin texture URL, or null/empty for no custom texture
     */
    public static ItemStack createHead(String mobName, String displayName, String textureUrl) {
        String key = mobName.toUpperCase(Locale.ROOT);
        Material material = VANILLA_HEADS.getOrDefault(key, Material.PLAYER_HEAD);
        ItemStack item = new ItemStack(material);

        SkullMeta meta = (SkullMeta) item.getItemMeta();
        if (meta != null) {
            meta.setDisplayName(ChatColor.YELLOW + displayName + ChatColor.GRAY + " Head");

            if (material == Material.PLAYER_HEAD && textureUrl != null && !textureUrl.isBlank()) {
                applyTexture(meta, textureUrl);
            }

            meta.getPersistentDataContainer().set(HeadKeys.mobType(), org.bukkit.persistence.PersistentDataType.STRING, key);
            item.setItemMeta(meta);
        }

        return item;
    }

    private static void applyTexture(SkullMeta meta, String textureUrl) {
        try {
            PlayerProfile profile = Bukkit.createProfile(UUID.randomUUID());
            PlayerTextures textures = profile.getTextures();
            textures.setSkin(new URL(textureUrl));
            profile.setTextures(textures);
            meta.setPlayerProfile(profile);
        } catch (MalformedURLException e) {
            // Bad URL in config; fall back to a plain head rather than crash.
        }
    }

    /**
     * Reads the EntityType name tag off a head item, or null if it isn't
     * one of ours.
     */
    public static String getMobType(ItemStack item) {
        if (item == null || !item.hasItemMeta()) {
            return null;
        }
        NamespacedKey key = HeadKeys.mobType();
        org.bukkit.persistence.PersistentDataContainer pdc = item.getItemMeta().getPersistentDataContainer();
        return pdc.get(key, org.bukkit.persistence.PersistentDataType.STRING);
    }
}
