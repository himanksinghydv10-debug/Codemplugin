package com.codemc.custommobpowers.listeners;

import com.codemc.custommobpowers.heads.HeadFactory;
import org.bukkit.configuration.ConfigurationSection;
import org.bukkit.entity.Creeper;
import org.bukkit.entity.LivingEntity;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.entity.EntityDamageEvent;
import org.bukkit.event.entity.EntityDeathEvent;
import org.bukkit.inventory.ItemStack;
import org.bukkit.plugin.Plugin;

import java.util.Locale;

/**
 * Vanilla behaviour: a charged (lightning-struck) creeper's explosion makes
 * nearby mobs drop their head. This listener replicates that but drops our
 * *custom power head* instead of / in addition to the vanilla mob head.
 */
public class MobDeathListener implements Listener {

    private final Plugin plugin;

    public MobDeathListener(Plugin plugin) {
        this.plugin = plugin;
    }

    @EventHandler
    public void onMobDeath(EntityDeathEvent event) {
        LivingEntity entity = event.getEntity();

        if (!wasKilledByChargedCreeper(event)) {
            return;
        }

        String mobName = entity.getType().name().toUpperCase(Locale.ROOT);
        ConfigurationSection textures = plugin.getConfig().getConfigurationSection("textures");
        String texture = textures != null ? textures.getString(mobName) : null;

        boolean hasUniquePower = mobName.equals("SLIME") || mobName.equals("CAVE_SPIDER")
                || mobName.equals("SPIDER") || mobName.equals("VEX");
        boolean hasConfiguredPower = plugin.getConfig().contains("default-powers." + mobName);

        if (!hasUniquePower && !hasConfiguredPower) {
            return; // this mob has no power, nothing special to drop
        }

        ItemStack head = HeadFactory.createHead(mobName, prettifyName(mobName), texture);
        entity.getWorld().dropItemNaturally(entity.getLocation(), head);
    }

    private boolean wasKilledByChargedCreeper(EntityDeathEvent event) {
        EntityDamageEvent damageEvent = event.getEntity().getLastDamageCause();
        if (damageEvent == null) {
            return false;
        }
        if (damageEvent.getCause() != EntityDamageEvent.DamageCause.ENTITY_EXPLOSION
                && damageEvent.getCause() != EntityDamageEvent.DamageCause.BLOCK_EXPLOSION) {
            return false;
        }
        if (!(damageEvent instanceof org.bukkit.event.entity.EntityDamageByEntityEvent byEntity)) {
            return false;
        }
        return byEntity.getDamager() instanceof Creeper creeper && creeper.isPowered();
    }

    private String prettifyName(String mobName) {
        String[] parts = mobName.toLowerCase(Locale.ROOT).split("_");
        StringBuilder builder = new StringBuilder();
        for (String part : parts) {
            if (!part.isEmpty()) {
                builder.append(Character.toUpperCase(part.charAt(0))).append(part.substring(1)).append(' ');
            }
        }
        return builder.toString().trim();
    }
}
