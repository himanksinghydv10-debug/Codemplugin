package com.codemc.custommobpowers.commands;

import com.codemc.custommobpowers.heads.HeadFactory;
import com.codemc.custommobpowers.powers.Power;
import com.codemc.custommobpowers.powers.PowerRegistry;
import org.bukkit.ChatColor;
import org.bukkit.command.Command;
import org.bukkit.command.CommandExecutor;
import org.bukkit.command.CommandSender;
import org.bukkit.entity.Player;
import org.bukkit.inventory.ItemStack;

/**
 * /removemobhead - any player can run this on themselves to take off
 * whatever mob head power they currently have active and get their
 * helmet slot cleared.
 *
 * This exists as a safety valve: the Vex power switches the wearer to
 * Spectator mode, and vanilla Spectator mode does not let players open
 * their own inventory to remove armor. Without a command like this a
 * player could get stuck. This command works regardless of game mode.
 */
public class RemoveMobHeadCommand implements CommandExecutor {

    private final PowerRegistry registry;

    public RemoveMobHeadCommand(PowerRegistry registry) {
        this.registry = registry;
    }

    @Override
    public boolean onCommand(CommandSender sender, Command command, String label, String[] args) {
        if (!(sender instanceof Player player)) {
            sender.sendMessage("Only players can use this command.");
            return true;
        }

        ItemStack helmet = player.getInventory().getHelmet();
        String mobType = HeadFactory.getMobType(helmet);

        if (mobType == null) {
            player.sendMessage(ChatColor.YELLOW + "You aren't wearing a mob power head.");
            return true;
        }

        Power power = registry.getPower(mobType);
        if (power != null) {
            power.onUnequip(player);
        }

        player.getInventory().setHelmet(null);
        player.sendMessage(ChatColor.GREEN + "Removed your mob head power.");
        return true;
    }
}
