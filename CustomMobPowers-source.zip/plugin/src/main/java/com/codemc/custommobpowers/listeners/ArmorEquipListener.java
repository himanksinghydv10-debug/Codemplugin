package com.codemc.custommobpowers.listeners;

import com.codemc.custommobpowers.heads.HeadFactory;
import com.codemc.custommobpowers.powers.Power;
import com.codemc.custommobpowers.powers.PowerRegistry;
import io.papermc.paper.event.player.PlayerArmorChangeEvent;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.EventPriority;
import org.bukkit.event.Listener;
import org.bukkit.inventory.EquipmentSlot;
import org.bukkit.inventory.ItemStack;

/**
 * This is the fix for "the power of the mob head is not working correctly".
 *
 * The previous version almost certainly tried to detect helmet changes via
 * InventoryClickEvent / PlayerJoinEvent only, which misses many ways a
 * helmet slot can change (shift-click, hotbar swap with 'F', dispenser
 * equipping, dying and respawning, commands, shift-clicking a full stack,
 * etc). Paper's PlayerArmorChangeEvent fires for every single one of those
 * cases in one place, so it is the reliable source of truth for "did the
 * player's helmet change".
 */
public class ArmorEquipListener implements Listener {

    private final PowerRegistry registry;

    public ArmorEquipListener(PowerRegistry registry) {
        this.registry = registry;
    }

    @EventHandler(priority = EventPriority.MONITOR)
    public void onArmorChange(PlayerArmorChangeEvent event) {
        if (event.getSlotType() != PlayerArmorChangeEvent.SlotType.HEAD) {
            return;
        }

        Player player = event.getPlayer();
        ItemStack oldItem = event.getOldItem();
        ItemStack newItem = event.getNewItem();

        String oldMobType = HeadFactory.getMobType(oldItem);
        String newMobType = HeadFactory.getMobType(newItem);

        if (oldMobType != null && oldMobType.equals(newMobType)) {
            return; // same head, nothing changed
        }

        if (oldMobType != null) {
            Power oldPower = registry.getPower(oldMobType);
            if (oldPower != null) {
                oldPower.onUnequip(player);
            }
        }

        if (newMobType != null) {
            Power newPower = registry.getPower(newMobType);
            if (newPower != null) {
                newPower.onEquip(player);
            }
        }
    }
}
