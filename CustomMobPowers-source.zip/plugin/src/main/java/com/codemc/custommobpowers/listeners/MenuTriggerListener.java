package com.codemc.custommobpowers.listeners;

import com.codemc.custommobpowers.menu.HeadMenu;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.player.PlayerSwapHandItemsEvent;
import org.bukkit.plugin.Plugin;

/**
 * Opens the mob head menu when a player presses the "Swap Hand Items" key
 * (default F, but the client can rebind this to any key, including Z).
 * Restricted to operators only, as requested.
 */
public class MenuTriggerListener implements Listener {

    private final Plugin plugin;

    public MenuTriggerListener(Plugin plugin) {
        this.plugin = plugin;
    }

    @EventHandler
    public void onSwapHands(PlayerSwapHandItemsEvent event) {
        Player player = event.getPlayer();
        if (!player.isOp()) {
            return;
        }

        event.setCancelled(true);
        player.openInventory(HeadMenu.build(plugin));
    }
}
