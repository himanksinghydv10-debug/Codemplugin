package com.codemc.custommobpowers.powers;

import org.bukkit.attribute.Attribute;
import org.bukkit.attribute.AttributeInstance;
import org.bukkit.entity.Player;
import org.bukkit.potion.PotionEffect;
import org.bukkit.potion.PotionEffectType;

/**
 * Slime head: shrinks the player and grants infinite Jump Boost,
 * mirroring a slime's small bouncy nature.
 */
public class SlimePower implements Power {

    private static final double SHRINK_SCALE = 0.5D;
    private static final int JUMP_BOOST_AMPLIFIER = 250; // very high jump, effectively "infinite" feeling
    private static final int INFINITE_DURATION = Integer.MAX_VALUE;

    @Override
    public void onEquip(Player player) {
        setScale(player, SHRINK_SCALE);
        applyJumpBoost(player);
    }

    @Override
    public void onUnequip(Player player) {
        setScale(player, 1.0D);
        player.removePotionEffect(PotionEffectType.JUMP);
    }

    @Override
    public void tick(Player player) {
        // Re-apply in case something else clears potion effects.
        PotionEffect current = player.getPotionEffect(PotionEffectType.JUMP);
        if (current == null || current.getAmplifier() != JUMP_BOOST_AMPLIFIER) {
            applyJumpBoost(player);
        }
    }

    private void applyJumpBoost(Player player) {
        player.addPotionEffect(new PotionEffect(
                PotionEffectType.JUMP,
                INFINITE_DURATION,
                JUMP_BOOST_AMPLIFIER,
                true,
                false,
                false
        ));
    }

    private void setScale(Player player, double scale) {
        AttributeInstance attribute = player.getAttribute(Attribute.GENERIC_SCALE);
        if (attribute != null) {
            attribute.setBaseValue(scale);
        }
    }
}
