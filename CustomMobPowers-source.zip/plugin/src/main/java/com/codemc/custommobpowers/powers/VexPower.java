package com.codemc.custommobpowers.powers;

import org.bukkit.GameMode;
import org.bukkit.entity.Player;

import java.util.HashMap;
import java.util.Map;
import java.util.UUID;

/**
 * Vex head: grants true flight and the ability to pass through walls.
 * The only reliable, dependency-free way to get real noclip in vanilla
 * Paper is Spectator game mode, so this power temporarily switches the
 * wearer to Spectator and restores their previous game mode on removal.
 *
 * Trade-off (vanilla limitation, not a bug): while in Spectator the
 * wearer is invisible to other players and cannot interact with
 * blocks/entities. If you want the player to stay visible/interactive
 * while noclipping, that requires a packet-manipulation library like
 * ProtocolLib and is a bigger change — ask if you want that version.
 */
public class VexPower implements Power {

    private final Map<UUID, GameMode> previousGameModes = new HashMap<>();
    private final boolean restorePreviousGamemode;

    public VexPower(boolean restorePreviousGamemode) {
        this.restorePreviousGamemode = restorePreviousGamemode;
    }

    @Override
    public void onEquip(Player player) {
        if (player.getGameMode() == GameMode.SPECTATOR) {
            return;
        }
        previousGameModes.put(player.getUniqueId(), player.getGameMode());
        player.setGameMode(GameMode.SPECTATOR);
    }

    @Override
    public void onUnequip(Player player) {
        GameMode previous = previousGameModes.remove(player.getUniqueId());
        if (restorePreviousGamemode && previous != null) {
            player.setGameMode(previous);
        } else if (player.getGameMode() == GameMode.SPECTATOR) {
            player.setGameMode(GameMode.SURVIVAL);
        }
    }
}
