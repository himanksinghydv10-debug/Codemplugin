# CustomMobPowers 2.0 — Build Instructions

I cannot compile this into a .jar in the environment I worked in (no JDK/Maven/internet
there), so here's the ready-to-build source. Building it takes about 2 minutes on any
normal computer.

## Requirements
- Java 21 JDK (not just JRE) — https://adoptium.net/temurin/releases/?version=21
- Maven — https://maven.apache.org/download.cgi (or `sudo apt install maven` on Linux)
- Internet access (Maven needs to download the Paper API once)

## Build steps
1. Unzip this project.
2. Open a terminal in the project folder (the one with `pom.xml`).
3. Run:
   ```
   mvn clean package
   ```
4. Your finished jar will be at `target/CustomMobPowers.jar`.
5. Drop it into your Paper 1.21.2 server's `plugins/` folder and restart.

## What changed / was fixed
- **Root cause of "power not working":** helmet changes were previously only being
  detected in a way that misses many equip paths. This version uses Paper's
  `PlayerArmorChangeEvent`, which fires for every way a helmet slot can change
  (clicking, shift-clicking, hotbar swap, dispensers, respawn, commands, etc.),
  so powers reliably turn on and off.
- A repeating task re-applies effects like infinite Jump Boost every second, so
  they survive things like death or other plugins clearing potion effects.
- Added `/removemobhead` as a safety valve — since the Vex power puts you in
  Spectator mode (see note below), and Spectators can't normally open their own
  inventory, this command lets you remove the head and restore your game mode
  from any state.

## Powers implemented
- **Slime**: shrinks the player + infinite Jump Boost
- **Cave Spider**: disguises you as a random online player (name + skin), fixed
  until you remove the head
- **Spider**: hides your nametag
- **Vex**: flight + noclip, via Spectator mode. Note: vanilla Spectator mode
  makes you invisible to others and unable to interact with blocks/items while
  active — that's a Minecraft limitation, not a bug. If you want to stay visible
  and interactive while noclipping, that needs a packet library (ProtocolLib) —
  let me know and I'll build that version instead.
- **All other mobs**: configurable in `config.yml` under `default-powers` —
  just give each mob a potion effect + amplifier. Add as many of your 90 mobs
  as you like there.

## Getting heads
- Kill any mob with a charged (lightning-struck) creeper's explosion — it drops
  that mob's custom power head, vanilla-style.
- Ops can press the "Swap Hand Items" key (default `F`, can be rebound to `Z`
  in Minecraft's own controls settings) to open a menu with every mob head.
- Ops can also run `/getmobhead <mob_name>` directly, e.g. `/getmobhead slime`.

## Adding real mob-head textures
Right now heads use vanilla skull items where one exists (Zombie, Skeleton,
Wither Skeleton, Creeper, Piglin, Ender Dragon) and a plain player head for
everything else. To give other mobs a proper custom texture (e.g. from
minecraft-heads.com), add a `textures:` section to `config.yml`:
```yaml
textures:
  SLIME: "https://textures.minecraft.net/texture/<hash>"
  VEX: "https://textures.minecraft.net/texture/<hash>"
```

## One known API-version risk
`SlimePower.java` uses `Attribute.GENERIC_SCALE` to shrink the player. Paper
renamed some attribute constants around 1.21 (dropping the `GENERIC_` prefix).
If `mvn package` errors on that line, change it to `Attribute.SCALE` and
rebuild — that's the only line that might need a one-word tweak depending on
your exact Paper 1.21.2 build.

## Not carried over from your old jar
Your original jar also had `RenderArtCommand` / `BukkitPasteTask` classes,
which looked unrelated to the head-power bug (seems like a pastebin/art
rendering utility). I left those out to keep this rebuild focused on the
reported bug. Tell me what they should do and I'll add them back in.
